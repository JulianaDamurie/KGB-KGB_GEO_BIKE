package kgb.kgbgeobike;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Cadastro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        final Button botaoS=findViewById(R.id.cadastro);
        botaoS.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String s = ((EditText)findViewById(R.id.cadastro_login)).getText().toString();
                Intent i=new Intent(Cadastro.this, Login.class);
                i.putExtra("usuario", s);
                startActivity(i);
            }
        });
    }
}
