package kgb.kgbgeobike;

import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.support.v4.widget.*;

public class Principal extends AppCompatActivity {
    private String[] mOpcoes;
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        mOpcoes= getResources().getStringArray(R.array.opcoes);
        mDrawerLayout=(DrawerLayout)findViewById(R.id.drawer);
        mDrawerList=(ListView)findViewById(R.id.janela);

        mDrawerList.setAdapter(new ArrayAdapter<String>(this, R.layout.drawer_list_item, mOpcoes));
        final String s=getIntent().getStringExtra("usuario");
    }
}